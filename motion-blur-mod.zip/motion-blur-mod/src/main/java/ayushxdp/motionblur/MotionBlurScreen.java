package ayushxdp.motionblur;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.SliderWidget;
import net.minecraft.text.Text;

import java.util.function.IntConsumer;

public class MotionBlurScreen extends Screen {
    private final Screen parent;
    private final MotionBlurConfig cfg = MotionBlurMod.config;

    public MotionBlurScreen(Screen parent) {
        super(Text.literal("Motion Blur Settings"));
        this.parent = parent;
    }

    private Text toggleText() {
        return Text.literal("Motion Blur: " + (cfg.enabled ? "ON" : "OFF"));
    }

    @Override
    protected void init() {
        int w = 200;
        int x = this.width / 2 - w / 2;
        int y = this.height / 4;

        addDrawableChild(ButtonWidget.builder(toggleText(), b -> {
            cfg.enabled = !cfg.enabled;
            b.setMessage(toggleText());
        }).dimensions(x, y, w, 20).build());

        addDrawableChild(new IntSlider(x, y + 26, w, 20, "Blur Strength", "%", 0, 95,
                cfg.strength, v -> cfg.strength = v));

        addDrawableChild(new IntSlider(x, y + 52, w, 20, "Target FPS", "", 30, 360,
                cfg.targetFps, v -> cfg.targetFps = v));

        addDrawableChild(ButtonWidget.builder(Text.literal("Reset to Defaults"), b -> {
            cfg.reset();
            this.clearAndInit();
        }).dimensions(x, y + 84, w, 20).build());

        addDrawableChild(ButtonWidget.builder(Text.literal("Done"), b -> close())
                .dimensions(x, y + 110, w, 20).build());
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        super.render(context, mouseX, mouseY, delta);
        context.drawCenteredTextWithShadow(this.textRenderer, this.title, this.width / 2, this.height / 4 - 20, 0xFFFFFFFF);
        context.drawCenteredTextWithShadow(this.textRenderer,
                Text.literal("Target FPS = the FPS you usually play at."), this.width / 2, this.height / 4 + 140, 0xFFAAAAAA);
        context.drawCenteredTextWithShadow(this.textRenderer,
                Text.literal("Settings apply when you press Done."), this.width / 2, this.height / 4 + 152, 0xFFAAAAAA);
    }

    @Override
    public void close() {
        cfg.save();
        boolean changed = PackInstaller.install(cfg);
        MotionBlurMod.resetAttempts();
        if (changed && this.client != null) this.client.reloadResources();
        if (this.client != null) this.client.setScreen(parent);
    }

    private static class IntSlider extends SliderWidget {
        private final String label;
        private final String suffix;
        private final int min;
        private final int max;
        private final IntConsumer onChange;

        IntSlider(int x, int y, int w, int h, String label, String suffix, int min, int max, int val, IntConsumer onChange) {
            super(x, y, w, h, Text.empty(), (double) (val - min) / (max - min));
            this.label = label;
            this.suffix = suffix;
            this.min = min;
            this.max = max;
            this.onChange = onChange;
            updateMessage();
        }

        private int current() {
            return min + (int) Math.round(this.value * (max - min));
        }

        @Override
        protected void updateMessage() {
            setMessage(Text.literal(label + ": " + current() + suffix));
        }

        @Override
        protected void applyValue() {
            onChange.accept(current());
        }
    }
}
