package ayushxdp.motionblur.mixin;

import ayushxdp.motionblur.MotionBlurPackProvider;
import net.minecraft.resource.ResourcePackManager;
import net.minecraft.resource.ResourcePackProvider;
import net.minecraft.resource.VanillaDataPackProvider;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Mutable;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.LinkedHashSet;
import java.util.Set;

@Mixin(ResourcePackManager.class)
public abstract class ResourcePackManagerMixin {
    @Mutable
    @Shadow
    @Final
    private Set<ResourcePackProvider> providers;

    @Inject(method = "<init>", at = @At("RETURN"))
    private void ayushmotionblur$addLockedPack(ResourcePackProvider[] given, CallbackInfo ci) {
        // Data pack managers (world / server) must not get our resource pack.
        for (ResourcePackProvider p : this.providers) {
            if (p instanceof VanillaDataPackProvider) return;
        }
        Set<ResourcePackProvider> set = new LinkedHashSet<>(this.providers);
        set.add(new MotionBlurPackProvider());
        this.providers = set;
    }
}
