package ayushxdp.motionblur;

import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Locale;

/**
 * Creates / updates the resource pack that does the actual motion blur.
 * The pack lives in config/ayushmotionblur/pack and is loaded as a LOCKED
 * (required + fixed position) pack, so it can't be disabled from the
 * resource pack screen. Remove the mod and the pack stops loading.
 */
public final class PackInstaller {
    public static final String PACK_ID = "ayushmotionblur_pack";

    private PackInstaller() {}

    public static Path packDir() {
        return FabricLoader.getInstance().getConfigDir().resolve("ayushmotionblur").resolve("pack");
    }

    private static final String MCMETA = """
            {
              "pack": {
                "description": "Motion Blur by AyushXDP (locked - managed by the mod)",
                "pack_format": 75,
                "min_format": 75,
                "max_format": 75
              }
            }
            """;

    private static final String BLEND_FSH = """
            #version 330

            uniform sampler2D InSampler;
            uniform sampler2D PrevSampler;

            layout(std140) uniform MotionBlurConfig {
                float Blend;
            };

            in vec2 texCoord;
            out vec4 fragColor;

            void main() {
                vec3 cur = texture(InSampler, texCoord).rgb;
                vec3 prev = texture(PrevSampler, texCoord).rgb;
                fragColor = vec4(mix(cur, prev, Blend), 1.0);
            }
            """;

    private static final String COPY_FSH = """
            #version 330

            uniform sampler2D InSampler;

            in vec2 texCoord;
            out vec4 fragColor;

            void main() {
                fragColor = vec4(texture(InSampler, texCoord).rgb, 1.0);
            }
            """;

    private static String effectJson(float blend) {
        String b = String.format(Locale.ROOT, "%.4f", blend);
        return """
                {
                  "targets": {
                    "swap": {},
                    "history": { "persistent": true }
                  },
                  "passes": [
                    {
                      "vertex_shader": "minecraft:core/screenquad",
                      "fragment_shader": "ayushmotionblur:post/motion_blur",
                      "inputs": [
                        { "sampler_name": "In", "target": "minecraft:main" },
                        { "sampler_name": "Prev", "target": "history" }
                      ],
                      "output": "swap",
                      "uniforms": {
                        "MotionBlurConfig": [
                          { "name": "Blend", "type": "float", "value": %s }
                        ]
                      }
                    },
                    {
                      "vertex_shader": "minecraft:core/screenquad",
                      "fragment_shader": "ayushmotionblur:post/copy",
                      "inputs": [
                        { "sampler_name": "In", "target": "swap" }
                      ],
                      "output": "history"
                    },
                    {
                      "vertex_shader": "minecraft:core/screenquad",
                      "fragment_shader": "ayushmotionblur:post/copy",
                      "inputs": [
                        { "sampler_name": "In", "target": "swap" }
                      ],
                      "output": "minecraft:main"
                    }
                  ]
                }
                """.formatted(b);
    }

    /** Writes the pack. Returns true if anything on disk changed. */
    public static boolean install(MotionBlurConfig cfg) {
        try {
            Path root = packDir();
            Path ns = root.resolve("assets").resolve("ayushmotionblur");
            boolean changed = false;
            changed |= write(root.resolve("pack.mcmeta"), MCMETA);
            changed |= write(ns.resolve("post_effect").resolve("motion_blur.json"), effectJson(cfg.blend()));
            changed |= write(ns.resolve("shaders").resolve("post").resolve("motion_blur.fsh"), BLEND_FSH);
            changed |= write(ns.resolve("shaders").resolve("post").resolve("copy.fsh"), COPY_FSH);
            return changed;
        } catch (IOException e) {
            MotionBlurMod.LOGGER.error("Failed to create the motion blur resource pack", e);
            return false;
        }
    }

    private static boolean write(Path file, String content) throws IOException {
        Files.createDirectories(file.getParent());
        if (Files.exists(file) && Files.readString(file).equals(content)) return false;
        Files.writeString(file, content);
        return true;
    }
}
