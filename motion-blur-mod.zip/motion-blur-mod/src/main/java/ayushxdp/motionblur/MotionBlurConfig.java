package ayushxdp.motionblur;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;

public class MotionBlurConfig {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();

    public boolean enabled = true;
    /** 0-95 (%). How much of the previous frame is kept at 60 FPS. */
    public int strength = 50;
    /** The FPS you usually play at, so the blur looks the same at any frame rate. */
    public int targetFps = 60;

    public void reset() {
        enabled = true;
        strength = 50;
        targetFps = 60;
    }

    /** Value written into the resource pack (0.0 - 0.97). */
    public float blend() {
        double s = Math.min(Math.max(strength, 0), 95) / 100.0;
        if (s <= 0) return 0f;
        double fps = Math.max(targetFps, 30);
        double k = Math.pow(s, 60.0 / fps);
        return (float) Math.min(k, 0.97);
    }

    private static Path file() {
        return FabricLoader.getInstance().getConfigDir().resolve("ayushmotionblur.json");
    }

    public static MotionBlurConfig load() {
        try {
            Path f = file();
            if (Files.exists(f)) {
                MotionBlurConfig c = GSON.fromJson(Files.readString(f), MotionBlurConfig.class);
                if (c != null) {
                    c.strength = Math.min(Math.max(c.strength, 0), 95);
                    c.targetFps = Math.min(Math.max(c.targetFps, 30), 360);
                    return c;
                }
            }
        } catch (Exception e) {
            MotionBlurMod.LOGGER.warn("Could not read config, using defaults", e);
        }
        MotionBlurConfig c = new MotionBlurConfig();
        c.save();
        return c;
    }

    public void save() {
        try {
            Files.writeString(file(), GSON.toJson(this));
        } catch (IOException e) {
            MotionBlurMod.LOGGER.warn("Could not save config", e);
        }
    }
}
