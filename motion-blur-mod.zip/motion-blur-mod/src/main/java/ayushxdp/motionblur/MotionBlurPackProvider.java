package ayushxdp.motionblur;

import net.minecraft.resource.DirectoryResourcePack;
import net.minecraft.resource.ResourcePackInfo;
import net.minecraft.resource.ResourcePackPosition;
import net.minecraft.resource.ResourcePackProfile;
import net.minecraft.resource.ResourcePackProvider;
import net.minecraft.resource.ResourcePackSource;
import net.minecraft.resource.ResourceType;
import net.minecraft.text.Text;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Optional;
import java.util.function.Consumer;

/** Offers the generated pack to the game as a required (locked) pack on top of the stack. */
public class MotionBlurPackProvider implements ResourcePackProvider {
    @Override
    public void register(Consumer<ResourcePackProfile> profileAdder) {
        Path dir = PackInstaller.packDir();
        if (!Files.isDirectory(dir)) {
            PackInstaller.install(MotionBlurMod.config != null ? MotionBlurMod.config : MotionBlurConfig.load());
        }
        if (!Files.isDirectory(dir)) return;

        ResourcePackInfo info = new ResourcePackInfo(
                PackInstaller.PACK_ID,
                Text.literal("Motion Blur (AyushXDP)"),
                ResourcePackSource.BUILTIN,
                Optional.empty());

        ResourcePackProfile profile = ResourcePackProfile.create(
                info,
                new DirectoryResourcePack.DirectoryBackedFactory(dir),
                ResourceType.CLIENT_RESOURCES,
                new ResourcePackPosition(true, ResourcePackProfile.InsertionPosition.TOP, true));

        if (profile != null) profileAdder.accept(profile);
    }
}
