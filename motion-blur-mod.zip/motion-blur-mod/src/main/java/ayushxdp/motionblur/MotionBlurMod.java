package ayushxdp.motionblur;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.screen.v1.ScreenEvents;
import net.fabricmc.fabric.api.client.screen.v1.Screens;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.option.VideoOptionsScreen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import org.lwjgl.glfw.GLFW;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/** Motion Blur - by AyushXDP. The blur lives in a locked resource pack; this class just manages it. */
public class MotionBlurMod implements ClientModInitializer {
    public static final String MOD_ID = "ayushmotionblur";
    public static final Logger LOGGER = LoggerFactory.getLogger("MotionBlur");
    public static final Identifier EFFECT_ID = Identifier.of(MOD_ID, "motion_blur");

    public static MotionBlurConfig config;

    private static KeyBinding openKey;
    private static int attempts = 0;
    private static boolean warned = false;

    @Override
    public void onInitializeClient() {
        config = MotionBlurConfig.load();
        PackInstaller.install(config);

        openKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.ayushmotionblur.open", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_K, KeyBinding.Category.MISC));

        // Button in Options > Video Settings (works with touch on Mojo / Pojav too).
        ScreenEvents.AFTER_INIT.register((client, screen, w, h) -> {
            if (screen instanceof VideoOptionsScreen) {
                ButtonWidget b = ButtonWidget.builder(Text.literal("Motion Blur"),
                        btn -> client.setScreen(new MotionBlurScreen(screen)))
                        .dimensions(6, 6, 90, 20).build();
                Screens.getButtons(screen).add(b);
            }
        });

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (openKey.wasPressed()) {
                if (client.currentScreen == null) client.setScreen(new MotionBlurScreen(null));
            }
            if (client.world == null || client.gameRenderer == null) return;

            Identifier cur = client.gameRenderer.getPostProcessorId();
            if (config.enabled) {
                if (EFFECT_ID.equals(cur)) {
                    attempts = 0;
                } else if (cur == null) {
                    if (attempts < 5) {
                        attempts++;
                        client.gameRenderer.setPostProcessor(EFFECT_ID);
                    } else if (!warned) {
                        warned = true;
                        LOGGER.warn("Motion blur shader keeps failing to load - check the log above for shader errors.");
                    }
                }
            } else if (EFFECT_ID.equals(cur)) {
                client.gameRenderer.clearPostProcessor();
            }
        });
    }

    public static void resetAttempts() {
        attempts = 0;
        warned = false;
    }
}
