# Motion Blur (by AyushXDP) - Fabric 1.21.11

- On launch the mod writes a resource pack to `config/ayushmotionblur/pack` and loads it as a LOCKED pack
  (always on, top of the list, can't be disabled). Remove the mod -> the pack is gone.
- The blur itself is done by the pack's post-effect shader (frame accumulation), not by mod render code.
- Settings: Options > Video Settings > "Motion Blur" button, or press K (rebindable).
  Press Done to apply (resources reload once if the shader values changed).

Build: push to GitHub (Actions builds it) or run `gradle build`. Fix versions in gradle.properties from https://fabricmc.net/develop
